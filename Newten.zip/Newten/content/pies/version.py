import os
import urllib.request

try:
    verURL = "https://raw.githubusercontent.com/MrNort64/newten/main/version.txt"
    verURLsource = urllib.request.urlopen(verURL)
    ver = verURLsource.read()
    f = open("./content/info/version.txt", "w")
    f.write(ver.decode())
    f.close()
except:
    e = open("./content/info/version.txt", "w")
    e.write("Native")
    e.close()